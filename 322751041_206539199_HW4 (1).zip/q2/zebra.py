# Igbaria Ahmad, 322751041
# Lana Shehab, 206539199

# Please replace the above comments with your names and ID numbers in the same format.

import numpy as np
from numpy.fft import fft2, ifft2, fftshift, ifftshift
import cv2
import matplotlib.pyplot as plt

image_path = 'zebra.jpg'
image = cv2.imread(image_path)
image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)


freq_domain = fft2(image)
centered_freq = fftshift(freq_domain)
log_spectrum = np.log(1 + np.absolute(centered_freq))

height, weight = image.shape[:2]
expanded_spectrum = np.zeros((height * 2, weight * 2), dtype=complex)
expanded_spectrum[height // 2:height // 2 + height, weight // 2:weight // 2 + weight] = centered_freq
expanded_image = np.abs(ifft2(ifftshift(expanded_spectrum)))
expanded_magnitude = np.log(1 + np.absolute(expanded_spectrum))

scale_a, scale_b = 2, 2
resized_spectrum = np.zeros((2 * height, 2 * weight), dtype=complex)

grid_x, grid_y = np.meshgrid(np.arange(height), np.arange(weight), indexing='ij')
mapped_x, mapped_y = (grid_x * scale_a).astype(int), (grid_y * scale_b).astype(int)

valid_positions = (mapped_x < 2 * height) & (mapped_y < 2 * weight)
resized_spectrum[mapped_x[valid_positions], mapped_y[valid_positions]] = freq_domain[grid_x[valid_positions], grid_y[valid_positions]] / (scale_a * scale_b)
centered_resized_spectrum = fftshift(resized_spectrum)


plt.figure(figsize=(10,10))
plt.subplot(321)
plt.title('Original Grayscale Image')
plt.imshow(image, cmap='gray')

plt.subplot(322)
plt.title('Fourier Spectrum')
plt.imshow(log_spectrum, cmap='gray')

plt.subplot(323)
plt.title('Fourier Spectrum Zero Padding')
plt.imshow(expanded_magnitude, cmap='gray')

plt.subplot(324)
plt.title('Two Times Larger Grayscale Image')
plt.imshow(expanded_image, cmap='gray')

plt.subplot(325)
plt.title('Fourier Spectrum Four Copies')
scaled_magnitude_spectrum = np.log(1 + np.abs(centered_resized_spectrum))
plt.imshow(scaled_magnitude_spectrum, cmap='gray')

plt.subplot(326)
plt.title('Four Copies Grayscale Image')
scaled_image = np.abs(ifft2(ifftshift(resized_spectrum)))
plt.imshow(scaled_image, cmap='gray')

plt.tight_layout()
plt.savefig('zebra_scaled.png')
plt.show()
