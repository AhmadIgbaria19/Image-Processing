# Igbaria Ahmad, 322751041
# Lana Shehab, 206539199

# Please replace the above comments with your names and ID numbers in the same format.

import numpy as np
from numpy.fft import fft2, ifft2, fftshift, ifftshift
import cv2
import matplotlib.pyplot as plt


def clean_baby(im):

    height, width = im.shape[:2]
    canvas_size = (width, height)
    denoised = cv2.medianBlur(im, ksize=3)
    canvas_pts = np.float32([[0, 0],[canvas_size[0] - 1, 0],[canvas_size[0] - 1, canvas_size[1] - 1],[0, canvas_size[1] - 1]])

    baby_points = {"baby_1": np.float32([[6, 19], [111, 20], [111, 130], [6, 130]]),
                   "baby_2": np.float32([[77, 162], [146, 116], [244, 160], [132, 245]]),
                   "baby_3": np.float32([[181, 4], [248, 71], [176, 121], [120, 49]])}
    warped_babies = []

    for baby, points in baby_points.items():
        transformation_matrix = cv2.getPerspectiveTransform(points, canvas_pts)
        warped_baby = cv2.warpPerspective(denoised, transformation_matrix, canvas_size)
        warped_babies.append(warped_baby)

    merged_image = np.median(np.array(warped_babies), axis=0).astype(np.uint8)
    return merged_image

def clean_windmill(im):

    fourier_transform = fft2(im)
    fourier_transform = fftshift(fourier_transform)
    center_x, center_y = im.shape[1] // 2, im.shape[0] // 2  
    noise_points = [(156, 132), (100, 124)] 

    for (x, y) in noise_points:
        sym_x = center_x - (x - center_x)  
        sym_y = center_y - (y - center_y)  
        fourier_transform[y, x] = 0
        fourier_transform[sym_y, sym_x] = 0  

    cleaned_windmill = np.abs(ifft2(ifftshift(fourier_transform)))
    return cleaned_windmill


def clean_watermelon(im):
    sharpening_kernel = np.array([[-1, -1, -1],
                                  [-1,  9, -1],
                                  [-1, -1, -1]], dtype=np.float32)

    sharpened_image = cv2.filter2D(im, -1, sharpening_kernel)

    return sharpened_image  

def clean_umbrella(im):
    image_complex = im.astype(np.complex128) 
    freq_transform = np.fft.fft2(image_complex)
    freq_mask = np.zeros((256, 256), dtype=np.float64)

    indices = [0 * 256 + 0, 4 * 256 + 79] 
    np.put(freq_mask, indices, 0.52)

    transformed_mask = np.fft.fft2(freq_mask)
    #min_val = np.min(np.abs(transformed_mask))
    #print(f"Lowest frequency value: {min_val}")
    min_val=0.01276239981714869
    transformed_mask = np.where(np.abs(transformed_mask) <min_val, 1, transformed_mask)
    invmask=1/transformed_mask
    filtered_transform=invmask*freq_transform
    inverse_shift = ifftshift(filtered_transform)
    restored_image = np.abs(ifft2(inverse_shift))

    return restored_image

def clean_USAflag(im):
    FixFlagImage= im.astype(np.uint8)
    K= np.ones((1, 70), dtype=np.float32)  
    K/=70  
    filtered_image = cv2.filter2D(FixFlagImage, -1, K)  

    FixFlagImage = filtered_image
    S=5
    FixFlagImage = cv2.medianBlur(FixFlagImage,S)
    Stars= np.zeros_like(im, dtype=np.uint8)
    Stars[:89, :142] = 1  
    FixFlagImage[Stars == 1] = im[Stars == 1]
    return FixFlagImage


def clean_house(im):
    image_complex = im.astype(np.complex128) 
    fourier_transform = np.fft.fft2(image_complex)
    
    height, width = im.shape[:2]  
    freq_mask = np.zeros((height, width), dtype=np.float64)  

    for i in range(10):
        freq_mask[0, i] = 0.1

    transformed_mask = np.fft.fft2(freq_mask)

    minvalue=np.min(np.abs(transformed_mask[np.abs(transformed_mask) > 0])) 
    #print(minvalue )

    low=max(minvalue,0.01)
    transformed_mask = np.where(np.abs(transformed_mask) <low, 1, transformed_mask)
    invmask=1/transformed_mask
    
    filtered_transform=invmask*fourier_transform
    inverse_shift = ifftshift(filtered_transform)
    FixedImage = np.abs(ifft2(inverse_shift))

    return FixedImage


def clean_bears(im):
    gamma = 2 
    invGamma = 1.0 / gamma
    table = np.array([(i / 255.0) ** invGamma * 255 for i in np.arange(0, 256)]).astype("uint8")
    brightened = cv2.LUT(im, table)
    equalized_image = cv2.equalizeHist(brightened)

    return equalized_image


