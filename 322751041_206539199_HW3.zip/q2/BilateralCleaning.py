# Igbaria Ahmad, 322751041
# Lana Shihab, 206539199

# Please replace the above comments with your names and ID numbers in the same format.

import cv2
import numpy as np
import matplotlib.pyplot as plt
import os

def clean_Gaussian_noise_bilateral(im, radius, stdSpatial, stdIntensity):
    im = im.astype(np.float64)
    height, width = im.shape
    cleanIm = np.zeros_like(im)

    y, x = np.meshgrid(np.arange(-radius, radius + 1), np.arange(-radius, radius + 1), indexing='ij')
    gs = np.exp(-(x**2 + y**2) / (2 * stdSpatial**2))

    for i in range(radius, height - radius):
        for j in range(radius, width - radius):

            window = im[i - radius:i + radius + 1, j - radius:j + radius + 1]
            gi = np.exp(-((window - im[i, j])**2) / (2 * stdIntensity**2))
            weights = gs * gi
            weights /= weights.sum()
            cleanIm[i, j] = np.sum(weights * window)

    return np.clip(cleanIm, 0, 255).astype(np.uint8)

images = {
    "taj.jpg": {"radius": 5, "stdSpatial": 10, "stdIntensity": 30},
    "NoisyGrayImage.png": {"radius": 7, "stdSpatial": 8, "stdIntensity": 65},
    "balls.jpg": {"radius": 4, "stdSpatial": 8, "stdIntensity": 25}
}

for image_name, params in images.items():
    image = cv2.imread(image_name, cv2.IMREAD_GRAYSCALE)
    if image is None:
        print(f"Unable to laod the image {image_name}")
        continue

    filtered_image = clean_Gaussian_noise_bilateral(
        image, 
        radius=params["radius"], 
        stdSpatial=params["stdSpatial"], 
        stdIntensity=params["stdIntensity"]
    )

    output_path = f"filtered_{image_name}"
    cv2.imwrite(output_path, filtered_image)
    print(f"Filtered image saved: {output_path}")
