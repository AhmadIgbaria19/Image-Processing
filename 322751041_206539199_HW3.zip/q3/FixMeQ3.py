# Igbaria Ahmad, 322751041
# Lana Shihab, 206539199

import cv2
import numpy as np
import matplotlib.pyplot as plt

# sectiona #####

def MedianMethod(image):
    WindowSize = 7
    ResultImage = cv2.medianBlur(image, WindowSize)
    return ResultImage

def GussianResult(image):
    KernelSize = 13
    ResultImage = cv2.GaussianBlur(image, (KernelSize, KernelSize), 0)
    return ResultImage

def BilateralMethod(image):
    d = 8
    sigmaColor = 70
    sigmaSpace = 70
    ResultImage = cv2.bilateralFilter(image, d, sigmaColor, sigmaSpace)
    ResultImage = cv2.medianBlur(ResultImage, 5)
    return ResultImage

BrokenImg = cv2.imread('broken.jpg', cv2.IMREAD_GRAYSCALE)  
MedianMethod_Result = MedianMethod(BrokenImg)
GussianMethod_Result = GussianResult(BrokenImg)
BilateralMethod_Result = BilateralMethod(BrokenImg)

cv2.imwrite('gaussian_filtered.jpg', GussianMethod_Result)
cv2.imwrite('median_filtered.jpg', MedianMethod_Result)
cv2.imwrite('bilateral_filtered.jpg', BilateralMethod_Result)

plt.figure(figsize=(15, 10))
plt.subplot(231), plt.title("Original Image"), plt.imshow(BrokenImg, cmap='gray'), plt.axis('off')
plt.subplot(232), plt.title("Gaussian Filtered"), plt.imshow(GussianMethod_Result, cmap='gray'), plt.axis('off')
plt.subplot(233), plt.title("Median Filtered"), plt.imshow(MedianMethod_Result, cmap='gray'), plt.axis('off')
plt.subplot(234), plt.title("Bilateral Filtered"), plt.imshow(BilateralMethod_Result, cmap='gray'), plt.axis('off')
plt.tight_layout()
plt.show()

######## section b ########### 
noised_images = np.load('noised_images.npy')
MedianImg = np.median(noised_images, axis=0)
ResultImg = MedianImg.astype(np.uint8)

cv2.imwrite('noisy_cleaned.jpg', ResultImg)
plt.figure(figsize=(10, 5))
plt.subplot(121)
plt.title("Example Noisy Image")
plt.imshow(noised_images[0], cmap='gray')  
plt.axis('off')
plt.subplot(122)
plt.title("Noisy Cleaned")
plt.imshow(ResultImg, cmap='gray')
plt.axis('off')
plt.tight_layout()
plt.show()
