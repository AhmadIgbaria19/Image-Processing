# Igbaria Ahmad, 322751041
# Lana Shihab, 206539199
import cv2
import numpy as np

def Mse_Calculated(img1, img2):
    diff_squared = (img1 - img2) ** 2
    mse = np.sum(diff_squared) / img1.size  
    return mse

print ( "the mse between the image and the his recreation: ")

original_image = cv2.imread("1.jpg", cv2.IMREAD_GRAYSCALE)
image_width = original_image.shape[1]
kernel_height = 1
kernel_width = image_width
kernel_matrix = np.ones((kernel_height, kernel_width), dtype=np.float32) / kernel_width
recreated_image_1 = cv2.filter2D(original_image, ddepth=-1, kernel=kernel_matrix, borderType=cv2.BORDER_WRAP)
image_1 = cv2.imread("image_1.jpg", cv2.IMREAD_GRAYSCALE)
mse_value = Mse_Calculated(image_1, recreated_image_1)
print(f"first mse = {mse_value}")
cv2.imwrite("recreations_1.jpg", recreated_image_1)

kernel_size = (11,11)  
sigma_value = 11 
blurred_image = cv2.GaussianBlur(original_image, kernel_size, sigma_value)
image_2_reference = cv2.imread("image_2.jpg", cv2.IMREAD_GRAYSCALE)
mse_value = Mse_Calculated(image_2_reference, blurred_image)
print(f'second mse = {mse_value}')
cv2.imwrite("recreations_2.jpg", blurred_image)

def apply_median_filter(image, window_size):
    return cv2.medianBlur(image, window_size)
original_image = cv2.imread("1.jpg", cv2.IMREAD_GRAYSCALE)
filter_size = 11
median_filtered_image = apply_median_filter(original_image, filter_size)
image_3 = cv2.imread("image_3.jpg", cv2.IMREAD_GRAYSCALE)
mse_value = Mse_Calculated(image_3, median_filtered_image)
print(f"third mse ={mse_value}")
cv2.imwrite("recreations_3.jpg", median_filtered_image)

kernel_height = 15 
kernel_width = 1
kernel = np.ones((kernel_height, kernel_width), dtype=np.float32) / kernel_height
recreation_4 = cv2.filter2D(original_image, ddepth=-1, kernel=kernel, borderType=cv2.BORDER_CONSTANT)
image_4 = cv2.imread("image_4.jpg", cv2.IMREAD_GRAYSCALE)
mse_value = Mse_Calculated(image_4, recreation_4)
print(f"fourth mse = {mse_value}")
cv2.imwrite("recreations_4.jpg", recreation_4)

blur_kernel = (11, 11) 
blur_sigma = 15  
blurred_image_5 = cv2.GaussianBlur(original_image, blur_kernel, blur_sigma)
offest=128
adjusted_image_5 = original_image - blurred_image_5 +offest 
image_5_reference = cv2.imread("image_5.jpg", cv2.IMREAD_GRAYSCALE)
mse_value_5 = Mse_Calculated(image_5_reference, adjusted_image_5)
print(f'fivth mse = {mse_value_5}')
cv2.imwrite("recreations_5.jpg", adjusted_image_5)

filtered_image_6 = cv2.filter2D(original_image, -1, kernel=np.array([[-1/9,-0.79,-1/9], [1/9,0,-1/9],[1/9,0.79,1/9]]))
gray_image_6 = cv2.imread("image_6.jpg", cv2.IMREAD_GRAYSCALE)
mse_value = Mse_Calculated(gray_image_6, filtered_image_6)
print('sixth mse=', mse_value)
cv2.imwrite("recreations_6.jpg", filtered_image_6)

mid=original_image.shape[0]//2
recreated_image_7 = np.vstack((original_image[mid:], original_image[:mid]))
image_7 = cv2.imread("image_7.jpg", cv2.IMREAD_GRAYSCALE)
mse_7 = Mse_Calculated(image_7, recreated_image_7)
print(f"seventh mse= {mse_7}")
cv2.imwrite("recreations_7.jpg", recreated_image_7)

original_image = cv2.imread("1.jpg", cv2.IMREAD_GRAYSCALE)
image_8 = cv2.imread("image_8.jpg", cv2.IMREAD_GRAYSCALE)
kernel = np.array([[0, 0, 0], [0, 1, 0], [0, 0, 0]], dtype=np.float32)
recreated_image_8 = cv2.filter2D(original_image, -1, kernel=kernel)
mse_8 = Mse_Calculated(image_8, recreated_image_8)
print(f"eight mse = {mse_8}")
cv2.imwrite("recreations_8.jpg", recreated_image_8)
