# Igbaria Ahmad, 322751041
# Lana Shihab, 206539199

# Please replace the above comments with your names and ID numbers in the same format.
import cv2
import numpy as np
import matplotlib.pyplot as plt

def get_laplacian_pyramid(image, levels, resize_ratio=0.5):
    gaussian_pyramid = [image.astype(np.float32)]
    laplacian_pyramid = []

    for _ in range(levels - 1):  
        blurred = cv2.GaussianBlur(gaussian_pyramid[-1], (5, 5), 0)
        downsampled = cv2.resize(blurred, None, fx=resize_ratio, fy=resize_ratio, interpolation=cv2.INTER_LINEAR)
        upsampled = cv2.resize(downsampled, (gaussian_pyramid[-1].shape[1], gaussian_pyramid[-1].shape[0]), interpolation=cv2.INTER_LINEAR)
        
        laplacian = cv2.subtract(gaussian_pyramid[-1], upsampled)  
        laplacian_pyramid.append(laplacian)
        gaussian_pyramid.append(downsampled)

    laplacian_pyramid.append(gaussian_pyramid[-1])  
    return laplacian_pyramid

def restore_from_pyramid(pyramidList, resize_ratio=2):
    image = pyramidList[-1]

    for laplacian in reversed(pyramidList[:-1]):
        upsampled = cv2.resize(image, (laplacian.shape[1], laplacian.shape[0]), interpolation=cv2.INTER_LINEAR)
        image = cv2.add(upsampled, laplacian)

    return np.clip(image, 0, 255).astype(np.uint8)

def validate_operation(img):
    pyr = get_laplacian_pyramid(img, levels=6)
    img_restored = restore_from_pyramid(pyr)

    mse = np.mean((img_restored - img) ** 2)
    plt.title(f"MSE is {mse:.4f}")
    plt.imshow(img_restored, cmap='gray')
    plt.show()

def blend_pyramids(levels):
    Pyramid_Result = []

    for level in range(levels):
        LapApple = ApplePyramid[level]
        LapOrange = OrangePyramid[level]

        rows,cols= LapApple.shape[:2]
        mask = np.zeros((rows, cols), dtype=np.float32)

        MidCol= cols // 2
        L_Limit = max(0, MidCol - level)  
        R_Limit = min(cols, MidCol + level)  

        mask[:, :L_Limit] = 1.0
        for i in range(L_Limit, R_Limit):
            mask[:, i] = 0.9 - 0.9 * (i - L_Limit) / (2 * level) # in the pdf alon say to ues that

        blended_laplacian = LapOrange * mask + LapApple * (1 - mask)
        Pyramid_Result.append(blended_laplacian)

    return Pyramid_Result



apple= cv2.imread('apple.jpg', cv2.IMREAD_GRAYSCALE)
orange = cv2.imread('orange.jpg', cv2.IMREAD_GRAYSCALE)

#validate_operation(apple)
#validate_operation(orange)

NumOflevels = 6
ApplePyramid= get_laplacian_pyramid(apple, NumOflevels)
OrangePyramid= get_laplacian_pyramid(orange, NumOflevels)

PyramidResult= blend_pyramids(NumOflevels)
FinalResult= restore_from_pyramid(PyramidResult)
plt.imshow(FinalResult, cmap='gray')
plt.show()

cv2.imwrite("result.jpg",FinalResult)
