# Igbaria Ahmad, 322751041
# Lana Shihab, 206539199

# Please replace the above comments with your names and ID numbers in the same format.

import cv2
import numpy as np
import matplotlib.pyplot as plt
from numpy.fft import fft2, ifft2, fftshift, ifftshift
from numpy.lib.stride_tricks import sliding_window_view
from scipy.ndimage import maximum_filter

def scale_down(image, resize_ratio):

    image = cv2.GaussianBlur(image, (5, 5), 0)  

    fft_image = np.fft.fft2(image)
    fft_shifted = np.fft.fftshift(fft_image)
    h,w = image.shape
    
    new_h, new_w = int(h * resize_ratio), int(w * resize_ratio)
    h_start, h_end = (h - new_h) // 2, (h + new_h) // 2
    w_start, w_end = (w - new_w) // 2, (w + new_w) // 2
    
    fft_cropped = fft_shifted[h_start:h_end, w_start:w_end]
    fft_cropped_shifted = np.fft.ifftshift(fft_cropped)
    scaled_image = np.fft.ifft2(fft_cropped_shifted).real
    result=cv2.normalize(scaled_image, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
	
    return result


def scale_up(image, resize_ratio):

    fshift = np.fft.fftshift(np.fft.fft2(image))

    rows, cols = image.shape
    new_rows, new_cols = (np.array([rows, cols]) * resize_ratio).astype(int)

    crop_start_row = (rows - new_rows) // 2
    crop_start_col = (cols - new_cols) // 2
    crop_start = (crop_start_row, crop_start_col)

    pad_start_row = (new_rows - rows) // 2
    pad_start_col = (new_cols - cols) // 2
    pad_start = (pad_start_row, pad_start_col)

    cropping_mode = new_rows < rows or new_cols < cols

    if cropping_mode:
        f_resized = fshift[crop_start[0]:crop_start[0] + new_rows, crop_start[1]:crop_start[1] + new_cols]
    else:
        f_resized = np.pad(fshift, ((pad_start[0], pad_start[0]), (pad_start[1], pad_start[1])), mode='constant')

    resized_image = np.abs(np.fft.ifft2(np.fft.ifftshift(f_resized)))
    result=cv2.normalize(resized_image, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)

    return result


def ncc_2d(input_image, template):
    image_windows = sliding_window_view(input_image, template.shape)
    
    template_mean = np.mean(template)
    template_centered = template - template_mean

    window_means = np.mean(image_windows, axis=(2, 3), keepdims=True)
    window_centered = image_windows - window_means

    cross_correlation = np.einsum('ijkl,kl->ij', window_centered, template_centered)  
    normalization_factor = np.sqrt(np.einsum('ijkl,ijkl->ij', window_centered, window_centered) *
                                   np.sum(template_centered**2))
    
    normalization_factor[normalization_factor == 0] = 1  
    result = cross_correlation / normalization_factor
    return result



def display(image, pattern):
	
	plt.subplot(2, 3, 1)
	plt.title('Image')
	plt.imshow(image, cmap='gray')
		
	plt.subplot(2, 3, 3)
	plt.title('Pattern')
	plt.imshow(pattern, cmap='gray', aspect='equal')
	
	ncc = ncc_2d(image, pattern)
	
	plt.subplot(2, 3, 5)
	plt.title('Normalized Cross-Correlation Heatmap')
	plt.imshow(ncc ** 2, cmap='coolwarm', vmin=0, vmax=1, aspect='auto') 
	
	cbar = plt.colorbar()
	cbar.set_label('NCC Values')
		
	plt.show()

def draw_matches(image, matches, pattern_size):
	image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
	for point in matches:
		y, x = point
		top_left = (int(x - pattern_size[1]/2), int(y - pattern_size[0]/2))
		bottom_right = (int(x + pattern_size[1]/2), int(y + pattern_size[0]/2))
		cv2.rectangle(image, top_left, bottom_right, (255, 0, 0), 1)
	
	plt.imshow(image, cmap='gray')
	plt.show()
	
	cv2.imwrite(f"{CURR_IMAGE}_result.jpg", image)

CURR_IMAGE = "students"
image = cv2.imread(f'{CURR_IMAGE}.jpg', cv2.IMREAD_GRAYSCALE)
pattern = cv2.imread('template.jpg', cv2.IMREAD_GRAYSCALE)
display(image, pattern)


############# Students #############
ScaleFactorThe1=1.9
scaled_image = scale_up(image,ScaleFactorThe1)
pattern_scaled = scale_down(pattern,1)
display(scaled_image, pattern_scaled)

ncc = ncc_2d(scaled_image, pattern_scaled)
FILTER_WINDOW = (45,35)
max_values = maximum_filter(ncc, size=FILTER_WINDOW)
ncc = (ncc == max_values) * ncc
real_matches = np.array(np.where(ncc >= 0.56)).T / ScaleFactorThe1
pattern_scaled = scale_down(pattern, 0.6)

######### DONT CHANGE THE NEXT TWO LINES #########
real_matches[:, 0] += pattern_scaled.shape[0] // 2
real_matches[:, 1] += pattern_scaled.shape[1] // 2

draw_matches(image, real_matches, pattern_scaled.shape)
############# Crew #############
CURR_IMAGE= "thecrew"
image2 = cv2.imread(f'{CURR_IMAGE}.jpg', cv2.IMREAD_GRAYSCALE)
pattern2 = cv2.imread('template.jpg', cv2.IMREAD_GRAYSCALE)

display(image2, pattern2)

ScaleFactorThe2=1.195
scaled_image = scale_up(image2, ScaleFactorThe2)
RatioSizeCr=0.325
pattern_scaled = scale_down(pattern2, RatioSizeCr)

display(image2, pattern_scaled)

ncc = ncc_2d(scaled_image,pattern_scaled)
FILTER_WINDOW =(25, 15)
max_values= maximum_filter(ncc, size=FILTER_WINDOW)
ncc = (ncc== max_values) * ncc  

real_matches = np.array(np.where(ncc >= 0.382)).T / ScaleFactorThe2
pattern_scaled = scale_down(pattern2,RatioSizeCr)

######### DONT CHANGE THE NEXT TWO LINES #########
real_matches[:, 0] += pattern_scaled.shape[0] // 2
real_matches[:, 1] += pattern_scaled.shape[1] // 2

draw_matches(image2, real_matches, pattern_scaled.shape)
