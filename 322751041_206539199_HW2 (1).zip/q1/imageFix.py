# Igbaria Ahmad, 322751041
# Lana Shehab, 206539199

# Please replace the above comments with your names and ID numbers in the same format.

import cv2
import matplotlib.pyplot as plt
import numpy as np

def Brightness_contrast_Method(image, contrast=1.0, brightness=0):
    corrected_image = cv2.convertScaleAbs(image, alpha=contrast, beta=brightness)
    return corrected_image


def gamma_correction_Method(image, gamma=1.0):
    table = np.zeros(256, dtype="uint8")
    for i in range(256):
        table[i] = int(((i / 255.0) ** gamma) * 255)    
    corrected_image = cv2.LUT(image, table)
    return corrected_image


def histogram_equalization_Method(image):
    equalized_image = cv2.equalizeHist(image)
    return equalized_image

def apply_fix(image, id):
    if id == 1:
        fixedImage= histogram_equalization_Method(image)
    elif id == 2:
        fixedImage = gamma_correction_Method(image,gamma=0.75)
    elif id ==3:
        fixedImage = Brightness_contrast_Method(image, contrast=0.4, brightness=-12)
    return fixedImage

for i in range(1, 4):
    path = f'{i}.jpg'
    image = cv2.imread(path, cv2.IMREAD_GRAYSCALE)
    fixed_image = apply_fix(image, i)
    plt.imsave(f'{i}_fixed.jpg', fixed_image, cmap='gray')

