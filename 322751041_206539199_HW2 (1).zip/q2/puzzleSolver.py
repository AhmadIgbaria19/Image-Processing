# Igbaria Ahmad, 322751041
# Lana Shehab, 206539199

# Please replace the above comments with your names and ID numbers in the same format.
import cv2
import numpy as np
import os
import shutil


def get_transform(matches, is_affine):
    src_points, dst_points = matches[:, 0], matches[:, 1]
	# Add your code here
    if is_affine==1:
        src_points , dst_points = src_points[:3].astype(np.float32) , dst_points[:3].astype(np.float32)
        transform_matrix = cv2.getAffineTransform(src_points, dst_points)
    else:
        src_points = src_points.astype(np.float32)
        dst_points = dst_points.astype(np.float32)
        transform_matrix ,_ = cv2.findHomography(src_points, dst_points)   
    T=transform_matrix      
    return T


# Output size is (w, h)
def inverse_transform_target_image(target_img, original_transform, is_affine, output_size):
    if is_affine: #check is_affine value
		#compute the inverse of the affine trans matrix for mapping back to the orginal coordinates
        InvTrans = cv2.invertAffineTransform(original_transform)  
        
		#apply the inverse affine trans to align the target image with canvas using specified output size and interpolation
        aligned_image = cv2.warpAffine(target_img, InvTrans, output_size[::-1], flags=2, borderMode=cv2.BORDER_TRANSPARENT) 
    else:
		#computer the inverese of the porjecteve trans matrix to map the target image back to the orgiinal canvas
        InvTrans = np.linalg.inv(original_transform)
        
        aligned_image = cv2.warpPerspective(target_img, InvTrans, output_size[::-1], flags=2,borderMode=cv2.BORDER_TRANSPARENT)  
        
    transformed_image =aligned_image #save the result    
    return transformed_image



def stitch(img1, img2):
    #we here check if img1.shape=img2.shape
    if img1.shape != img2.shape:
        raise ValueError("Error")
    #create a binary mask where pixels in img2 greaterthan 0 are marked true , else false 
    mask = img2 > 0 

    stitched_image = img1.copy()
    stitched_image[mask] = img2[mask]

    return stitched_image

# returns list of pieces file names
def prepare_puzzle(puzzle_dir):
    edited = os.path.join(puzzle_dir, 'abs_pieces')
    if os.path.exists(edited):
        shutil.rmtree(edited)
    os.mkdir(edited)

    affine = 4 - int("affine" in puzzle_dir)

    matches_data = os.path.join(puzzle_dir, 'matches.txt')
    n_images = len(os.listdir(os.path.join(puzzle_dir, 'pieces')))

    matches = np.loadtxt(matches_data, dtype=np.int64).reshape(n_images - 1, affine, 2, 2)

    return matches, affine == 3, n_images


if __name__ == '__main__':
    lst = ['puzzle_affine_1', 'puzzle_affine_2', 'puzzle_homography_1']

    for puzzle_dir in lst:
        print(f'Starting {puzzle_dir}')

        puzzle = os.path.join('puzzles', puzzle_dir)

        pieces_pth = os.path.join(puzzle, 'pieces')
        edited = os.path.join(puzzle, 'abs_pieces')
        matches, is_affine, n_images = prepare_puzzle(puzzle)
        base_piece  = cv2.imread(os.path.join(pieces_pth, 'piece_1.jpg'))
        
        end_range= n_images + 1
        start_range=2
        step=1
        final_puzzle =np.copy(base_piece)
        
        for i in range(start_range, end_range, step):
            piece_path  = os.path.join(pieces_pth, f'piece_{i}.jpg')
            piece_img  = cv2.imread(piece_path)
            trans_matrix  = get_transform(matches[i - 2], is_affine)
            aligned_img = inverse_transform_target_image(piece_img, trans_matrix, is_affine, base_piece .shape[:2])
            filename = f'piece_{i}_absolute.jpg'
            cv2.imwrite(os.path.join(edited, filename), aligned_img)
            final_puzzle  = stitch(final_puzzle , aligned_img)

        sol_file = f'solution.jpg'
        cv2.imwrite(os.path.join(puzzle, sol_file), final_puzzle )
